                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.4 #17089 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module main
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-small
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main
                                     12 	.globl _CY
                                     13 	.globl _AC
                                     14 	.globl _F0
                                     15 	.globl _RS1
                                     16 	.globl _RS0
                                     17 	.globl _OV
                                     18 	.globl _F1
                                     19 	.globl _P
                                     20 	.globl _PS
                                     21 	.globl _PT1
                                     22 	.globl _PX1
                                     23 	.globl _PT0
                                     24 	.globl _PX0
                                     25 	.globl _RD
                                     26 	.globl _WR
                                     27 	.globl _T1
                                     28 	.globl _T0
                                     29 	.globl _INT1
                                     30 	.globl _INT0
                                     31 	.globl _TXD
                                     32 	.globl _RXD
                                     33 	.globl _P3_7
                                     34 	.globl _P3_6
                                     35 	.globl _P3_5
                                     36 	.globl _P3_4
                                     37 	.globl _P3_3
                                     38 	.globl _P3_2
                                     39 	.globl _P3_1
                                     40 	.globl _P3_0
                                     41 	.globl _EA
                                     42 	.globl _ES
                                     43 	.globl _ET1
                                     44 	.globl _EX1
                                     45 	.globl _ET0
                                     46 	.globl _EX0
                                     47 	.globl _P2_7
                                     48 	.globl _P2_6
                                     49 	.globl _P2_5
                                     50 	.globl _P2_4
                                     51 	.globl _P2_3
                                     52 	.globl _P2_2
                                     53 	.globl _P2_1
                                     54 	.globl _P2_0
                                     55 	.globl _SM0
                                     56 	.globl _SM1
                                     57 	.globl _SM2
                                     58 	.globl _REN
                                     59 	.globl _TB8
                                     60 	.globl _RB8
                                     61 	.globl _TI
                                     62 	.globl _RI
                                     63 	.globl _P1_7
                                     64 	.globl _P1_6
                                     65 	.globl _P1_5
                                     66 	.globl _P1_4
                                     67 	.globl _P1_3
                                     68 	.globl _P1_2
                                     69 	.globl _P1_1
                                     70 	.globl _P1_0
                                     71 	.globl _TF1
                                     72 	.globl _TR1
                                     73 	.globl _TF0
                                     74 	.globl _TR0
                                     75 	.globl _IE1
                                     76 	.globl _IT1
                                     77 	.globl _IE0
                                     78 	.globl _IT0
                                     79 	.globl _P0_7
                                     80 	.globl _P0_6
                                     81 	.globl _P0_5
                                     82 	.globl _P0_4
                                     83 	.globl _P0_3
                                     84 	.globl _P0_2
                                     85 	.globl _P0_1
                                     86 	.globl _P0_0
                                     87 	.globl _B
                                     88 	.globl _ACC
                                     89 	.globl _PSW
                                     90 	.globl _IP
                                     91 	.globl _P3
                                     92 	.globl _IE
                                     93 	.globl _P2
                                     94 	.globl _SBUF
                                     95 	.globl _SCON
                                     96 	.globl _P1
                                     97 	.globl _TH1
                                     98 	.globl _TH0
                                     99 	.globl _TL1
                                    100 	.globl _TL0
                                    101 	.globl _TMOD
                                    102 	.globl _TCON
                                    103 	.globl _PCON
                                    104 	.globl _DPH
                                    105 	.globl _DPL
                                    106 	.globl _SP
                                    107 	.globl _P0
                                    108 ;--------------------------------------------------------
                                    109 ; special function registers
                                    110 ;--------------------------------------------------------
                                    111 	.area RSEG    (ABS,DATA)
      000000                        112 	.org 0x0000
                           000080   113 _P0	=	0x0080
                           000081   114 _SP	=	0x0081
                           000082   115 _DPL	=	0x0082
                           000083   116 _DPH	=	0x0083
                           000087   117 _PCON	=	0x0087
                           000088   118 _TCON	=	0x0088
                           000089   119 _TMOD	=	0x0089
                           00008A   120 _TL0	=	0x008a
                           00008B   121 _TL1	=	0x008b
                           00008C   122 _TH0	=	0x008c
                           00008D   123 _TH1	=	0x008d
                           000090   124 _P1	=	0x0090
                           000098   125 _SCON	=	0x0098
                           000099   126 _SBUF	=	0x0099
                           0000A0   127 _P2	=	0x00a0
                           0000A8   128 _IE	=	0x00a8
                           0000B0   129 _P3	=	0x00b0
                           0000B8   130 _IP	=	0x00b8
                           0000D0   131 _PSW	=	0x00d0
                           0000E0   132 _ACC	=	0x00e0
                           0000F0   133 _B	=	0x00f0
                                    134 ;--------------------------------------------------------
                                    135 ; special function bits
                                    136 ;--------------------------------------------------------
                                    137 	.area RSEG    (ABS,DATA)
      000000                        138 	.org 0x0000
                           000080   139 _P0_0	=	0x0080
                           000081   140 _P0_1	=	0x0081
                           000082   141 _P0_2	=	0x0082
                           000083   142 _P0_3	=	0x0083
                           000084   143 _P0_4	=	0x0084
                           000085   144 _P0_5	=	0x0085
                           000086   145 _P0_6	=	0x0086
                           000087   146 _P0_7	=	0x0087
                           000088   147 _IT0	=	0x0088
                           000089   148 _IE0	=	0x0089
                           00008A   149 _IT1	=	0x008a
                           00008B   150 _IE1	=	0x008b
                           00008C   151 _TR0	=	0x008c
                           00008D   152 _TF0	=	0x008d
                           00008E   153 _TR1	=	0x008e
                           00008F   154 _TF1	=	0x008f
                           000090   155 _P1_0	=	0x0090
                           000091   156 _P1_1	=	0x0091
                           000092   157 _P1_2	=	0x0092
                           000093   158 _P1_3	=	0x0093
                           000094   159 _P1_4	=	0x0094
                           000095   160 _P1_5	=	0x0095
                           000096   161 _P1_6	=	0x0096
                           000097   162 _P1_7	=	0x0097
                           000098   163 _RI	=	0x0098
                           000099   164 _TI	=	0x0099
                           00009A   165 _RB8	=	0x009a
                           00009B   166 _TB8	=	0x009b
                           00009C   167 _REN	=	0x009c
                           00009D   168 _SM2	=	0x009d
                           00009E   169 _SM1	=	0x009e
                           00009F   170 _SM0	=	0x009f
                           0000A0   171 _P2_0	=	0x00a0
                           0000A1   172 _P2_1	=	0x00a1
                           0000A2   173 _P2_2	=	0x00a2
                           0000A3   174 _P2_3	=	0x00a3
                           0000A4   175 _P2_4	=	0x00a4
                           0000A5   176 _P2_5	=	0x00a5
                           0000A6   177 _P2_6	=	0x00a6
                           0000A7   178 _P2_7	=	0x00a7
                           0000A8   179 _EX0	=	0x00a8
                           0000A9   180 _ET0	=	0x00a9
                           0000AA   181 _EX1	=	0x00aa
                           0000AB   182 _ET1	=	0x00ab
                           0000AC   183 _ES	=	0x00ac
                           0000AF   184 _EA	=	0x00af
                           0000B0   185 _P3_0	=	0x00b0
                           0000B1   186 _P3_1	=	0x00b1
                           0000B2   187 _P3_2	=	0x00b2
                           0000B3   188 _P3_3	=	0x00b3
                           0000B4   189 _P3_4	=	0x00b4
                           0000B5   190 _P3_5	=	0x00b5
                           0000B6   191 _P3_6	=	0x00b6
                           0000B7   192 _P3_7	=	0x00b7
                           0000B0   193 _RXD	=	0x00b0
                           0000B1   194 _TXD	=	0x00b1
                           0000B2   195 _INT0	=	0x00b2
                           0000B3   196 _INT1	=	0x00b3
                           0000B4   197 _T0	=	0x00b4
                           0000B5   198 _T1	=	0x00b5
                           0000B6   199 _WR	=	0x00b6
                           0000B7   200 _RD	=	0x00b7
                           0000B8   201 _PX0	=	0x00b8
                           0000B9   202 _PT0	=	0x00b9
                           0000BA   203 _PX1	=	0x00ba
                           0000BB   204 _PT1	=	0x00bb
                           0000BC   205 _PS	=	0x00bc
                           0000D0   206 _P	=	0x00d0
                           0000D1   207 _F1	=	0x00d1
                           0000D2   208 _OV	=	0x00d2
                           0000D3   209 _RS0	=	0x00d3
                           0000D4   210 _RS1	=	0x00d4
                           0000D5   211 _F0	=	0x00d5
                           0000D6   212 _AC	=	0x00d6
                           0000D7   213 _CY	=	0x00d7
                                    214 ;--------------------------------------------------------
                                    215 ; overlayable register banks
                                    216 ;--------------------------------------------------------
                                    217 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        218 rbank0:	.ds 8
                                    219 ;--------------------------------------------------------
                                    220 ; internal ram data
                                    221 ;--------------------------------------------------------
                                    222 	.area DSEG    (DATA)
                                    223 ;--------------------------------------------------------
                                    224 ; overlayable items in internal ram
                                    225 ;--------------------------------------------------------
                                    226 	.area	OSEG    (OVR,DATA)
                                    227 ;--------------------------------------------------------
                                    228 ; Stack segment in internal ram
                                    229 ;--------------------------------------------------------
                                    230 	.area SSEG
      000008                        231 __start__stack:
      000008                        232 	.ds	1
                                    233 
                                    234 ;--------------------------------------------------------
                                    235 ; indirectly addressable internal ram data
                                    236 ;--------------------------------------------------------
                                    237 	.area ISEG    (DATA)
                                    238 ;--------------------------------------------------------
                                    239 ; absolute internal ram data
                                    240 ;--------------------------------------------------------
                                    241 	.area IABS    (ABS,DATA)
                                    242 	.area IABS    (ABS,DATA)
                                    243 ;--------------------------------------------------------
                                    244 ; bit data
                                    245 ;--------------------------------------------------------
                                    246 	.area BSEG    (BIT)
                                    247 ;--------------------------------------------------------
                                    248 ; paged external ram data
                                    249 ;--------------------------------------------------------
                                    250 	.area PSEG    (PAG,XDATA)
                                    251 ;--------------------------------------------------------
                                    252 ; uninitialized external ram data
                                    253 ;--------------------------------------------------------
                                    254 	.area XSEG    (XDATA)
                                    255 ;--------------------------------------------------------
                                    256 ; absolute external ram data
                                    257 ;--------------------------------------------------------
                                    258 	.area XABS    (ABS,XDATA)
                                    259 ;--------------------------------------------------------
                                    260 ; initialized external ram data
                                    261 ;--------------------------------------------------------
                                    262 	.area XISEG   (XDATA)
                                    263 	.area HOME    (CODE)
                                    264 	.area GSINIT0 (CODE)
                                    265 	.area GSINIT1 (CODE)
                                    266 	.area GSINIT2 (CODE)
                                    267 	.area GSINIT3 (CODE)
                                    268 	.area GSINIT4 (CODE)
                                    269 	.area GSINIT5 (CODE)
                                    270 	.area GSINIT  (CODE)
                                    271 	.area GSFINAL (CODE)
                                    272 	.area CSEG    (CODE)
                                    273 ;--------------------------------------------------------
                                    274 ; interrupt vector
                                    275 ;--------------------------------------------------------
                                    276 	.area HOME    (CODE)
      000000                        277 __interrupt_vect:
      000000 02 00 4D         [24]  278 	ljmp	__sdcc_gsinit_startup
                                    279 ; restartable atomic support routines
      000003                        280 	.ds	5
      000008                        281 sdcc_atomic_compare_exchange_gptr_impl::
      000008 30 F6 15         [24]  282 	jnb	b.6, sdcc_atomic_compare_exchange_xdata_impl
      00000B A8 82            [24]  283 	mov	r0, dpl
      00000D 20 F5 08         [24]  284 	jb	b.5, sdcc_atomic_compare_exchange_pdata_impl
      000010                        285 sdcc_atomic_exchange_rollback_start::
      000010                        286 sdcc_atomic_compare_exchange_idata_impl:
      000010 E6               [12]  287 	mov	a, @r0
      000011 B5 02 02         [24]  288 	cjne	a, ar2, .+#5
      000014 EB               [12]  289 	mov	a, r3
      000015 F6               [12]  290 	mov	@r0, a
      000016 22               [24]  291 	ret
      000017 00               [12]  292 	nop
      000018                        293 sdcc_atomic_compare_exchange_pdata_impl:
      000018 E2               [24]  294 	movx	a, @r0
      000019 B5 02 02         [24]  295 	cjne	a, ar2, .+#5
      00001C EB               [12]  296 	mov	a, r3
      00001D F2               [24]  297 	movx	@r0, a
      00001E 22               [24]  298 	ret
      00001F 00               [12]  299 	nop
      000020                        300 sdcc_atomic_compare_exchange_xdata_impl:
      000020 E0               [24]  301 	movx	a, @dptr
      000021 B5 02 02         [24]  302 	cjne	a, ar2, .+#5
      000024 EB               [12]  303 	mov	a, r3
      000025 F0               [24]  304 	movx	@dptr, a
      000026 22               [24]  305 	ret
      000027 00               [12]  306 	nop
      000028 00               [12]  307 	nop
      000029 00               [12]  308 	nop
      00002A                        309 sdcc_atomic_exchange_pdata_impl:
      00002A E2               [24]  310 	movx	a, @r0
      00002B FB               [12]  311 	mov	r3, a
      00002C EA               [12]  312 	mov	a, r2
      00002D F2               [24]  313 	movx	@r0, a
      00002E 80 06            [24]  314 	sjmp	sdcc_atomic_exchange_exit
      000030 00               [12]  315 	nop
      000031 00               [12]  316 	nop
      000032                        317 sdcc_atomic_exchange_xdata_impl:
      000032 E0               [24]  318 	movx	a, @dptr
      000033 FB               [12]  319 	mov	r3, a
      000034 EA               [12]  320 	mov	a, r2
      000035 F0               [24]  321 	movx	@dptr, a
      000036                        322 sdcc_atomic_exchange_rollback_end::
                                    323 
      000036                        324 sdcc_atomic_exchange_exit:
      000036 8B 82            [24]  325 	mov	dpl, r3
      000038 22               [24]  326 	ret
      000039                        327 _atomic_flag_test_and_set::
      000039 7A 01            [12]  328 	mov	r2, #1
      00003B                        329 sdcc_atomic_exchange_gptr_impl::
      00003B 30 F6 F4         [24]  330 	jnb	b.6, sdcc_atomic_exchange_xdata_impl
      00003E A8 82            [24]  331 	mov	r0, dpl
      000040 20 F5 E7         [24]  332 	jb	b.5, sdcc_atomic_exchange_pdata_impl
      000043                        333 sdcc_atomic_exchange_idata_impl:
      000043 EA               [12]  334 	mov	a, r2
      000044 C6               [12]  335 	xch	a, @r0
      000045 F5 82            [12]  336 	mov	dpl, a
      000047 22               [24]  337 	ret
                                    338 ;--------------------------------------------------------
                                    339 ; global & static initialisations
                                    340 ;--------------------------------------------------------
                                    341 	.area HOME    (CODE)
                                    342 	.area GSINIT  (CODE)
                                    343 	.area GSFINAL (CODE)
                                    344 	.area GSINIT  (CODE)
                                    345 	.globl __sdcc_gsinit_startup
                                    346 	.globl __sdcc_program_startup
                                    347 	.globl __start__stack
                                    348 	.globl __mcs51_genXINIT
                                    349 	.globl __mcs51_genXRAMCLEAR
                                    350 	.globl __mcs51_genRAMCLEAR
                                    351 	.area GSFINAL (CODE)
      0000A6 02 00 48         [24]  352 	ljmp	__sdcc_program_startup
                                    353 ;--------------------------------------------------------
                                    354 ; Home
                                    355 ;--------------------------------------------------------
                                    356 	.area HOME    (CODE)
                                    357 	.area HOME    (CODE)
      000048                        358 __sdcc_program_startup:
      000048 12 00 C7         [24]  359 	lcall	_main
      00004B                        360 __sdcc_program_exit:
      00004B 80 FE            [24]  361 	sjmp	.
                                    362 ;	return from main will return to caller
                                    363 ;--------------------------------------------------------
                                    364 ; code
                                    365 ;--------------------------------------------------------
                                    366 	.area CSEG    (CODE)
                                    367 ;------------------------------------------------------------
                                    368 ;Allocation info for local variables in function 'delay_ms'
                                    369 ;------------------------------------------------------------
                                    370 ;ms            Allocated to registers 
                                    371 ;------------------------------------------------------------
                                    372 ;	../main.c:11: static void delay_ms(unsigned char ms)
                                    373 ;	-----------------------------------------
                                    374 ;	 function delay_ms
                                    375 ;	-----------------------------------------
      0000A9                        376 _delay_ms:
                           000007   377 	ar7 = rbank0 + 0x07
                           000006   378 	ar6 = rbank0 + 0x06
                           000005   379 	ar5 = rbank0 + 0x05
                           000004   380 	ar4 = rbank0 + 0x04
                           000003   381 	ar3 = rbank0 + 0x03
                           000002   382 	ar2 = rbank0 + 0x02
                           000001   383 	ar1 = rbank0 + 0x01
                           000000   384 	ar0 = rbank0 + 0x00
      0000A9 AF 82            [24]  385 	mov	r7, dpl
                                    386 ;	../main.c:13: while (ms--)
      0000AB                        387 00104$:
      0000AB 8F 06            [24]  388 	mov	ar6,r7
      0000AD 1F               [12]  389 	dec	r7
      0000AE EE               [12]  390 	mov	a,r6
      0000AF 60 15            [24]  391 	jz	00107$
                                    392 ;	../main.c:15: TR0 = 0;
                                    393 ;	assignBit
      0000B1 C2 8C            [12]  394 	clr	_TR0
                                    395 ;	../main.c:16: TH0 = 0xFC;
      0000B3 75 8C FC         [24]  396 	mov	_TH0,#0xfc
                                    397 ;	../main.c:17: TL0 = 0x66;  /* 922 timer ticks: about 1 ms */
      0000B6 75 8A 66         [24]  398 	mov	_TL0,#0x66
                                    399 ;	../main.c:18: TF0 = 0;
                                    400 ;	assignBit
      0000B9 C2 8D            [12]  401 	clr	_TF0
                                    402 ;	../main.c:19: TR0 = 1;
                                    403 ;	assignBit
      0000BB D2 8C            [12]  404 	setb	_TR0
                                    405 ;	../main.c:20: while (!TF0) { }
      0000BD                        406 00101$:
      0000BD 30 8D FD         [24]  407 	jnb	_TF0,00101$
                                    408 ;	../main.c:21: TR0 = 0;
                                    409 ;	assignBit
      0000C0 C2 8C            [12]  410 	clr	_TR0
                                    411 ;	../main.c:22: TF0 = 0;
                                    412 ;	assignBit
      0000C2 C2 8D            [12]  413 	clr	_TF0
      0000C4 80 E5            [24]  414 	sjmp	00104$
      0000C6                        415 00107$:
                                    416 ;	../main.c:24: }
      0000C6 22               [24]  417 	ret
                                    418 ;------------------------------------------------------------
                                    419 ;Allocation info for local variables in function 'main'
                                    420 ;------------------------------------------------------------
                                    421 ;stable        Allocated to registers r7 
                                    422 ;sample        Allocated to registers r6 
                                    423 ;------------------------------------------------------------
                                    424 ;	../main.c:26: void main(void)
                                    425 ;	-----------------------------------------
                                    426 ;	 function main
                                    427 ;	-----------------------------------------
      0000C7                        428 _main:
                                    429 ;	../main.c:28: unsigned char stable = 1;
      0000C7 7F 01            [12]  430 	mov	r7,#0x01
                                    431 ;	../main.c:30: BUTTON = 1;  /* release input latch */
                                    432 ;	assignBit
      0000C9 D2 B2            [12]  433 	setb	_P3_2
                                    434 ;	../main.c:31: LED = 0;
                                    435 ;	assignBit
      0000CB C2 90            [12]  436 	clr	_P1_0
                                    437 ;	../main.c:32: TMOD = (TMOD & 0xF0) | 0x01;
      0000CD E5 89            [12]  438 	mov	a,_TMOD
      0000CF 54 F0            [12]  439 	anl	a,#0xf0
      0000D1 44 01            [12]  440 	orl	a,#0x01
      0000D3 F5 89            [12]  441 	mov	_TMOD,a
                                    442 ;	../main.c:33: while (1)
      0000D5                        443 00106$:
                                    444 ;	../main.c:35: sample = BUTTON;
      0000D5 A2 B2            [12]  445 	mov	c,_P3_2
      0000D7 E4               [12]  446 	clr	a
      0000D8 33               [12]  447 	rlc	a
                                    448 ;	../main.c:36: if (sample != stable)
      0000D9 FE               [12]  449 	mov	r6,a
      0000DA B5 07 02         [24]  450 	cjne	a,ar7,00131$
      0000DD 80 F6            [24]  451 	sjmp	00106$
      0000DF                        452 00131$:
                                    453 ;	../main.c:38: delay_ms(20);
      0000DF 75 82 14         [24]  454 	mov	dpl, #0x14
      0000E2 C0 07            [24]  455 	push	ar7
      0000E4 C0 06            [24]  456 	push	ar6
      0000E6 12 00 A9         [24]  457 	lcall	_delay_ms
      0000E9 D0 06            [24]  458 	pop	ar6
      0000EB D0 07            [24]  459 	pop	ar7
                                    460 ;	../main.c:39: if (BUTTON == sample)
      0000ED A2 B2            [12]  461 	mov	c,_P3_2
      0000EF E4               [12]  462 	clr	a
      0000F0 33               [12]  463 	rlc	a
      0000F1 8E 04            [24]  464 	mov	ar4,r6
      0000F3 B5 04 DF         [24]  465 	cjne	a,ar4,00106$
                                    466 ;	../main.c:41: stable = sample;
                                    467 ;	../main.c:42: LED = (stable == 0);
      0000F6 EE               [12]  468 	mov	a,r6
      0000F7 FF               [12]  469 	mov	r7,a
      0000F8 24 FF            [12]  470 	add	a, #0xff
      0000FA B3               [12]  471 	cpl	c
      0000FB 92 90            [24]  472 	mov	_P1_0,c
                                    473 ;	../main.c:46: }
      0000FD 80 D6            [24]  474 	sjmp	00106$
                                    475 	.area CSEG    (CODE)
                                    476 	.area CONST   (CODE)
                                    477 	.area XINIT   (CODE)
                                    478 	.area CABS    (ABS,CODE)
